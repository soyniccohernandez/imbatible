<style>
    .dataTables_filter {
        width: 100%;
        margin: 2rem 0;
    }

    .dataTables_filter label {
        width: 100%;
    }

    .dataTables_filter label input {
        width: 100%;
        display: block;
        width: 100%;
        padding: 0.375rem 0.75rem;
        font-size: 1rem;
        font-weight: 400;
        line-height: 1.5;
        color: var(--bs-body-color);
        -webkit-appearance: none;
        -moz-appearance: none;
        appearance: none;
        background-color: var(--bs-body-bg);
        background-clip: padding-box;
        border: var(--bs-border-width) solid var(--bs-border-color);
        border-radius: var(--bs-border-radius);
        transition: border-color .15s ease-in-out, box-shadow .15s ease-in-out;
    }

    .dataTables_paginate {
        text-align: center;
        margin-top: 10px;
    }

    .dataTables_paginate a {
        display: inline-block;
        padding: 5px 10px;
        margin: 0 2px;
        text-decoration: none;
        color: #333;
        border: 1px solid #ccc;
        border-radius: 3px;
        background-color: #fff;
    }

    .dataTables_paginate a:hover {
        background-color: #f0f0f0;
    }

    .dataTables_paginate .current {
        background-color: #007bff;
        color: #fff;
        border-color: #007bff;
    }

    .dataTables_paginate .disabled {
        pointer-events: none;
        color: #999;
    }

    .dataTables_info {
        margin: 2rem 0;
    }
</style>

<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>



    <?php if(isset($success)): ?>

        <script>
            Swal.fire({
                title: 'Desinscripción Imbatible',
                text: ' <?php echo e($success); ?>',
                icon: 'success',
                confirmButtonText: 'Aceptar'
            })
        </script>

        <?php endif; ?>
        <div class="py-12">
            <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
                <div class="container">

                    <nav style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb" class="mb-5">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item text-primary"><a href="<?php echo e(route('dashboard')); ?>">Administración</a>
                            </li>
                            <li class="breadcrumb-item active text-primary" aria-current="page">Inscritos</li>
                        </ol>
                    </nav>
                    <p class="fs-1">Listado Inscritos</p>

                    <table id="inscritosTable" class="table display w-100">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Nombre</th>
                                <th>Email</th>
                                <th>Medio de pago</th>
                                <th>Soporte de pago</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $inscritos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inscrito): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($inscrito->nombre_completo); ?></td>
                                    <td><?php echo e($inscrito->correo_electronico); ?></td>
                                    <td><?php echo e($inscrito->medio_pago); ?></td>
                                    <td> <a href="#" class="nav-link text-primary">Descargar aquí</a> </td>
                                    <td>
                                        <a href="<?php echo e(url('inscritos/' . $inscrito->id)); ?>" class="btn btn-primary btn-sm">Ver
                                            info completa</a>
                                    </td>
                                    <!-- Agrega más celdas según los campos que desees mostrar -->
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>


     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\TI\Desktop\imbatible\resources\views/inscritos/index.blade.php ENDPATH**/ ?>